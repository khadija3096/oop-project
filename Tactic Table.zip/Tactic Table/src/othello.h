// othello.h
#pragma once
void RunOthello();
