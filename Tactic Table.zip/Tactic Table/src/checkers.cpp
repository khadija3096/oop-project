#include "raylib.h"
#include <iostream>
#include <cmath>
#include <ctime>

// FINAL (POLYMORPHISM)

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 800;
const int TILE_SIZE = 100;
const int BOARD_SIZE = 8;

Color lightTile = {238, 204, 136, 255};
//Color darkTile = {153, 102, 51, 255};

Color darkTile = {120, 50, 40, 255};

Color blackPiece = {40, 40, 40, 255};
Color whitePiece = {230, 230, 230, 255};

Color kingCrown = {105, 105, 105, 255};

enum GameState { MENU, INSTRUCTIONS, PLAYING };
GameState currentState = MENU;

void DrawMenu() {
    ClearBackground(darkTile);
    DrawText("CHECKERS", 280, 100, 50, lightTile);

    DrawRectangle(300, 250, 200, 50, lightTile);
    DrawText("Start Game", 320, 260, 20, BLACK);

    DrawRectangle(300, 330, 200, 50, lightTile);
    DrawText("Instructions", 310, 340, 20, BLACK);

    DrawRectangle(300, 410, 200, 50, lightTile);
    DrawText("Quit Game", 320, 420, 20, BLACK);
}

void DrawInstructions() {
    ClearBackground(darkTile);
    DrawText("HOW TO PLAY CHECKERS", 200, 50, 30, lightTile);
    DrawText("1. Each player starts with 12 pieces.", 100, 150, 20, lightTile);
    DrawText("2. Pieces move diagonally.", 100, 180, 20, lightTile);
    DrawText("3. Capture opponent pieces by jumping over.", 100, 210, 20, lightTile);
    DrawText("4. Reach the far side to king your piece.", 100, 240, 20, lightTile);
    DrawText("5. Kings can move both forward and backward.", 100, 270, 20, lightTile);
    DrawText("6. You must make a capture if one is available.", 100, 300, 20, lightTile);

    DrawRectangle(300, 600, 200, 50, lightTile);
    DrawText("Back to Menu", 310, 615, 20, BLACK);
}

enum Player { HUMAN, AI, NONE };

class PieceBase {
    protected:
        bool isKing;
        bool isAI;
        int row, col;
    
    public:
        PieceBase(bool ai = false, int r = 0, int c = 0) : isKing(false), isAI(ai), row(r), col(c) {}
        virtual ~PieceBase() {}
    
        void MakeKing() { isKing = true; }
        bool IsKing() const { return isKing; }
        bool IsAI() const { return isAI; }
        int GetRow() const { return row; }
        int GetCol() const { return col; }
        void MoveTo(int r, int c) { row = r; col = c; }
    
        virtual void Draw() const = 0; // Pure virtual
};

class HumanPiece : public PieceBase {
    public:
        HumanPiece(int r, int c) : PieceBase(false, r, c) {}
    
        void Draw() const override {
            DrawCircle(col * TILE_SIZE + TILE_SIZE / 2, row * TILE_SIZE + TILE_SIZE / 2, TILE_SIZE / 3, blackPiece);
            if (isKing) DrawText("K", col * TILE_SIZE + 40, row * TILE_SIZE + 30, 20, WHITE);
        }
    };
    
    class AIPiece : public PieceBase {
    public:
        AIPiece(int r, int c) : PieceBase(true, r, c) {}
    
        void Draw() const override {
            DrawCircle(col * TILE_SIZE + TILE_SIZE / 2, row * TILE_SIZE + TILE_SIZE / 2, TILE_SIZE / 3, whitePiece);
            if (isKing) DrawText("K", col * TILE_SIZE + 40, row * TILE_SIZE + 30, 20, BLACK);
        }
    };
    
    

class Board {
private:
    PieceBase* board[BOARD_SIZE][BOARD_SIZE];

public:
    Board() { Reset(); }

    ~Board() {
        for (int r = 0; r < BOARD_SIZE; ++r)
            for (int c = 0; c < BOARD_SIZE; ++c)
                delete board[r][c];
    }

    void Reset() {
        for (int r = 0; r < BOARD_SIZE; ++r)
            for (int c = 0; c < BOARD_SIZE; ++c)
                board[r][c] = nullptr;

        for (int r = 0; r < 3; ++r)
            for (int c = (r + 1) % 2; c < BOARD_SIZE; c += 2)
                board[r][c] = new AIPiece(r, c);

        for (int r = BOARD_SIZE - 3; r < BOARD_SIZE; ++r)
            for (int c = (r + 1) % 2; c < BOARD_SIZE; c += 2)
                board[r][c] = new HumanPiece(r, c);
        }

    // Returns the pointer to the piece at (r, c) if within bounds, otherwise returns nullptr
    PieceBase* GetPiece(int r, int c) const {
        if (r < 0 || r >= BOARD_SIZE || c < 0 || c >= BOARD_SIZE) return nullptr; // Check if coordinates are out of bounds
        return board[r][c]; // Return the piece pointer at (r, c)
    }

    // Moves a piece from (r1, c1) to (r2, c2)
    void MovePiece(int r1, int c1, int r2, int c2) {
        board[r2][c2] = board[r1][c1]; // Move the piece pointer to the new location
        board[r1][c1] = nullptr;       // Clear the old location

        if (board[r2][c2]) 
            board[r2][c2]->MoveTo(r2, c2); // Update the piece's internal position

        // Check if the piece should be kinged after the move
        if (board[r2][c2] && !board[r2][c2]->IsKing()) { // if there is a piece at the destination (r2, c2), and that piece is not already a king.
            // If it's an AI piece and reached the last row OR it's a player's piece and reached the top
            if ((board[r2][c2]->IsAI() && r2 == BOARD_SIZE - 1) || (!board[r2][c2]->IsAI() && r2 == 0)) {
                board[r2][c2]->MakeKing(); // Promote to king
            }
        }
    }

    void RemovePiece(int r, int c) {
        delete board[r][c];      // Free the memory of the piece
        board[r][c] = nullptr;   // Mark the cell as empty
    }

    // Draws the entire checkers board along with all the pieces on it
    void Draw() const {
        for (int r = 0; r < BOARD_SIZE; ++r) { // Loop through each row of the board
            for (int c = 0; c < BOARD_SIZE; ++c) {  // Loop through each column of the board
                Color tileColor = ((r + c) % 2 == 0) ? lightTile : darkTile; // // Determine the color of the tile based on its position
                DrawRectangle(c * TILE_SIZE, r * TILE_SIZE, TILE_SIZE, TILE_SIZE, tileColor); // Draw the tile at position (c, r) using the chosen color
                if (board[r][c]) { // If there's a piece on this tile, draw it
                    board[r][c]->Draw(); // Call the piece's own Draw() method
                }
            }
        }
    }

    // Checks if the given side (AI or player) has any legal moves left
    bool HasMoves(bool isAI) const {
        int dr[4] = {1, 1, -1, -1};  // down, down, up, up
        int dc[4] = {-1, 1, -1, 1};  // left, right, left, right
    
        // Loop through all positions on the board
        for (int r = 0; r < BOARD_SIZE; ++r) {
            for (int c = 0; c < BOARD_SIZE; ++c) {
                PieceBase* p = board[r][c];
                if (p && p->IsAI() == isAI) { // If there's a piece and it belongs to the side being checked
                    for (int d = 0; d < 4; ++d) { // Try all 4 diagonal directions
                        // Non-king pieces can only move forward:
                        // AI moves downward (dr[d] > 0), player moves upward (dr[d] < 0)
                        if (!p->IsKing() && ((isAI && dr[d] < 0) || (!isAI && dr[d] > 0))) continue;
    
                        // -------- Check for normal move --------
                        int nr = r + dr[d];  // New row
                        int nc = c + dc[d];  // New column

                         // If the new position is within bounds and empty, a move is possible
                        if (nr >= 0 && nr < BOARD_SIZE && nc >= 0 && nc < BOARD_SIZE &&
                            board[nr][nc] == nullptr)
                            return true;
    
                         // -------- Check for capture move --------
                        int mr = r + dr[d]; // Middle piece row: the square right next to current piece in direction `d`
                        int mc = c + dc[d]; // Middle piece column: same, but for column
                        int tr = r + 2 * dr[d]; // Target row after capture: 2 steps ahead in direction `d`
                        int tc = c + 2 * dc[d]; // Target column after capture: 2 steps ahead in direction `d`
                        if (tr >= 0 && tr < BOARD_SIZE && tc >= 0 && tc < BOARD_SIZE) { // // If capture target is within bounds
                            // Gets the piece in the middle square (the one we’d try to jump over).
                            PieceBase* middle = board[mr][mc];
                              // Check if there's an opponent piece to jump over and the landing spot is empty
                            if (middle && middle->IsAI() != p->IsAI() && board[tr][tc] == nullptr)
                                return true;
                        }
                    }
                }
            }
        }
         
        // If no legal moves found, return false
        return false;
    }

    // Checks if the player (AI or human) has any forced capture available.
    bool HasForcedCaptures(bool isAI) const {
        // Iterate over all squares on the board
        for (int r = 0; r < BOARD_SIZE; ++r) {
            for (int c = 0; c < BOARD_SIZE; ++c) {
                PieceBase* p = board[r][c];

                // Proceed only if the current square has a piece belonging to the current player
                if (p && p->IsAI() == isAI) {
                    // Possible direction vectors for movement (down-left, down-right, up-left, up-right)
                    int dr[4] = {1, 1, -1, -1};  // Row changes
                    int dc[4] = {-1, 1, -1, 1};  // Column changes

                    // Check each direction for possible capture
                    for (int d = 0; d < 4; ++d) {
                        // Skip directions that are not allowed for non-king pieces
                        // AI can only move down (dr > 0), human can only move up (dr < 0)
                        if (!p->IsKing() && ((isAI && dr[d] < 0) || (!isAI && dr[d] > 0)))
                            continue;

                        // Middle coordinates — position of the piece to be captured
                        int mr = r + dr[d];
                        int mc = c + dc[d];

                        // Target coordinates — the square the piece will land on after jumping
                        int tr = r + 2 * dr[d];
                        int tc = c + 2 * dc[d];

                        // Make sure the landing square is within the board boundaries
                        if (tr >= 0 && tr < BOARD_SIZE && tc >= 0 && tc < BOARD_SIZE) {
                            PieceBase* middle = board[mr][mc];

                            // Check if:
                            // 1. There's an opponent's piece in the middle to capture
                            // 2. The target square is empty
                            if (board[tr][tc] == nullptr &&
                                middle && middle->IsAI() != p->IsAI()) {
                                // A valid forced capture is found
                                return true;
                            }
                        }
                    }
                }
            }
        }

        // No forced captures found on the board
        return false;
    }

    bool CanCapture(PieceBase* p) const {
        // If the piece pointer is invalid (nullptr), return false
        if (!p) return false;
        
        // Get the current row and column of the piece
        int r = p->GetRow();
        int c = p->GetCol();

        // Directions for potential capture (up-left, up-right, down-left, down-right)
        int dr[4] = {1, 1, -1, -1}; // Row direction adjustments for each direction
        int dc[4] = {-1, 1, -1, 1}; // Column direction adjustments for each direction

        // Loop through all four possible directions
        for (int d = 0; d < 4; ++d) {
            // Skip the direction if the piece is not a king and it would move incorrectly based on its type
            if (!p->IsKing() && ((p->IsAI() && dr[d] < 0) || (!p->IsAI() && dr[d] > 0))) continue;

            // Calculate the position of the middle piece (the one we might jump over)
            int mr = r + dr[d]; // Middle piece row
            int mc = c + dc[d]; // Middle piece column

            // Calculate the target position (where the piece would land after the capture)
            int tr = r + 2 * dr[d]; // Target row
            int tc = c + 2 * dc[d]; // Target column

            // Check if the target position is within bounds of the board
            if (tr >= 0 && tr < BOARD_SIZE && tc >= 0 && tc < BOARD_SIZE) {
                // Get the piece in the middle and check if it can be captured
                PieceBase* middle = board[mr][mc];

                // Check if:
                // 1. The target position is empty (no piece in the landing position)
                // 2. The middle piece exists and is an opponent's piece (its AI status is different from the current piece's AI status)
                if (board[tr][tc] == nullptr && middle && middle->IsAI() != p->IsAI()) {
                    // If all conditions are met, return true, meaning the piece can make a capture
                    return true;
                }
            }
        }

        // If no capture move was found, return false
        return false;
    }




};

int RunCheckers() {
    // Initialize the game window
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Checkers Game");
    SetTargetFPS(60); // Limit frame rate to 60 FPS

    // Game variables
    Board board;  // The game board
    Player currentTurn = HUMAN;  // Tracks whose turn it is
    PieceBase* selectedPiece = nullptr;  // Currently selected piece by the player
    bool gameOver = false;  // Flag to track game over state
    Player winner = NONE;  // Who won the game
    float endTimer = 0;  // Timer for displaying end screen
    float aiWaitTimer = 0;  // Timer to delay AI actions (for visibility)
    float invalidMoveTimer = 0;  // Timer for showing "invalid move" message
    bool showInvalidMove = false;  // Should we show invalid move message?
    bool playerMultiCapture = false;  // Is player in a multi-capture sequence?
    bool aiMultiCapture = false;  // Is AI in a multi-capture sequence?
    int aiCaptureRow = -1, aiCaptureCol = -1;  // Track AI piece position during multi-capture
    int lastCaptureRow = -1, lastCaptureCol = -1;  // Track player piece position during multi-capture

    // Main game loop
    while (!WindowShouldClose()) {
        BeginDrawing();  // Start rendering frame

        // ------------------ MENU SCREEN LOGIC ------------------
        if (currentState == MENU) {
            DrawMenu();  // Render main menu UI

            // Handle mouse clicks in menu
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                int mouseX = GetMouseX();
                int mouseY = GetMouseY();

                // Check menu button bounds
                if (mouseX >= 300 && mouseX <= 500) {
                    if (mouseY >= 250 && mouseY <= 300) {
                        currentState = PLAYING;  // Start the game
                    } else if (mouseY >= 330 && mouseY <= 380) {
                        currentState = INSTRUCTIONS;  // Go to instructions screen
                    } else if (mouseY >= 410 && mouseY <= 460) {
                        CloseWindow();  // Exit game
                        return 0;
                    }
                }
            }

            EndDrawing();
            continue;  // Skip rest of frame for menu screen
        }

        // ------------------ INSTRUCTIONS SCREEN LOGIC ------------------
        if (currentState == INSTRUCTIONS) {
            DrawInstructions();  // Render instructions UI

            // Back to menu if button clicked
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                int mouseX = GetMouseX();
                int mouseY = GetMouseY();

                if (mouseX >= 300 && mouseX <= 500 && mouseY >= 600 && mouseY <= 650) {
                    currentState = MENU;
                }
            }

            EndDrawing();
            continue;  // Skip rest of frame for instructions screen
        }

        // ------------------ GAME SCREEN ------------------
        if (currentState == PLAYING)
        {
            ClearBackground(RAYWHITE);  // Clear screen

            board.Draw();  // Draw current board state

            // Draw button to quit to menu
            DrawRectangle(650, 10, 140, 40, GRAY);
            DrawText("Quit to Menu", 660, 20, 20, BLACK);

            // Handle click on quit button
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                int mouseX = GetMouseX();
                int mouseY = GetMouseY();

                if (mouseX >= 650 && mouseX <= 790 && mouseY >= 10 && mouseY <= 50) {
                    // Reset all game state and return to menu
                    currentState = MENU;
                    selectedPiece = nullptr;
                    playerMultiCapture = false;
                    aiMultiCapture = false;
                    gameOver = false;
                    winner = NONE;
                    board.Reset();  // Clear board
                    continue;
                }
            }

            // Display whose turn it is
            DrawText(currentTurn == HUMAN ? "Player Turn" : "AI Turn", 10, 10, 30, GRAY);

            // Show "Invalid move" warning if active
            if (showInvalidMove) {
                DrawText("Invalid move: Capture is available!", 200, 750, 25, RED);
                invalidMoveTimer += GetFrameTime();
                if (invalidMoveTimer > 3.0f) {
                    showInvalidMove = false;
                    invalidMoveTimer = 0;
                }
            }

            // Show end screen if game over
            if (gameOver) {
                const char* result = (winner == HUMAN) ? "YOU WIN" : "YOU LOSE";
                Color color = (winner == HUMAN) ? GREEN : RED;
                DrawText(result, 300, 350, 40, color);

                endTimer += GetFrameTime();
                if (endTimer > 5) {
                    DrawText("Click to Play Again", 270, 420, 30, BLACK);
                    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                        board.Reset();
                        selectedPiece = nullptr;
                        currentTurn = HUMAN;
                        winner = NONE;
                        gameOver = false;
                        endTimer = 0;
                        aiWaitTimer = 0;
                    }
                }

                EndDrawing();
                continue;
            }

            // ------------------ HUMAN TURN ------------------
            if (currentTurn == HUMAN && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                int x = GetMouseX() / TILE_SIZE;
                int y = GetMouseY() / TILE_SIZE;
                PieceBase* clicked = board.GetPiece(y, x);

                // If not in multi-capture mode
                if (!playerMultiCapture) {
                    // Select own piece
                    if (clicked && !clicked->IsAI()) {
                        selectedPiece = clicked;
                    } else if (selectedPiece) {
                        int sr = selectedPiece->GetRow();
                        int sc = selectedPiece->GetCol();
                        int dr = y - sr;
                        int dc = x - sc;

                        bool forced = board.HasForcedCaptures(false);  // Are captures forced?
                        bool isCapture = (abs(dr) == 2 && abs(dc) == 2);
                        bool isNormalMove = (abs(dr) == 1 && abs(dc) == 1);

                        // Validate movement direction for non-kings
                        if (!selectedPiece->IsKing()) {
                            if ((dr > 0 && !selectedPiece->IsAI()) || (dr < 0 && selectedPiece->IsAI())) {
                                selectedPiece = nullptr;
                                EndDrawing();
                                continue;
                            }
                        }

                        // Disallow non-capture when forced capture exists
                        if (forced && !isCapture) {
                            showInvalidMove = true;
                            selectedPiece = nullptr;
                            EndDrawing();
                            continue;
                        }

                        int mr = sr + dr / 2;
                        int mc = sc + dc / 2;

                        // Execute capture move
                        if (isCapture) {
                            PieceBase* middle = board.GetPiece(mr, mc);
                            if (middle && middle->IsAI() != selectedPiece->IsAI() && board.GetPiece(y, x) == nullptr) {
                                board.MovePiece(sr, sc, y, x);
                                board.RemovePiece(mr, mc);
                                selectedPiece = board.GetPiece(y, x);
                                if (board.CanCapture(selectedPiece)) {
                                    playerMultiCapture = true;
                                    lastCaptureRow = y;
                                    lastCaptureCol = x;
                                } else {
                                    selectedPiece = nullptr;
                                    playerMultiCapture = false;
                                    currentTurn = AI;
                                }
                            } else {
                                selectedPiece = nullptr;
                            }
                        }
                        // Normal non-capture move
                        else if (isNormalMove && !forced && board.GetPiece(y, x) == nullptr) {
                            board.MovePiece(sr, sc, y, x);
                            selectedPiece = nullptr;
                            currentTurn = AI;
                        } else {
                            selectedPiece = nullptr;
                        }
                    }
                } else {
                    // Multi-capture in progress
                    if (selectedPiece) {
                        int sr = selectedPiece->GetRow();
                        int sc = selectedPiece->GetCol();
                        int dr = y - sr;
                        int dc = x - sc;

                        bool isCapture = (abs(dr) == 2 && abs(dc) == 2);
                        int mr = sr + dr / 2;
                        int mc = sc + dc / 2;

                        if (isCapture) {
                            PieceBase* middle = board.GetPiece(mr, mc);
                            if (middle && middle->IsAI() != selectedPiece->IsAI() && board.GetPiece(y, x) == nullptr) {
                                board.MovePiece(sr, sc, y, x);
                                board.RemovePiece(mr, mc);
                                selectedPiece = board.GetPiece(y, x);
                                if (board.CanCapture(selectedPiece)) {
                                    playerMultiCapture = true;
                                    lastCaptureRow = y;
                                    lastCaptureCol = x;
                                } else {
                                    selectedPiece = nullptr;
                                    playerMultiCapture = false;
                                    currentTurn = AI;
                                }
                            }
                        }
                    }
                }
            }

            // ------------------ AI TURN ------------------
            if (currentTurn == AI) {
                aiWaitTimer += GetFrameTime();
                if (aiWaitTimer > 1.0f) {  // Delay for visual pacing
                    bool madeMove = false;

                    // Try to perform a capture
                    for (int r = 0; r < BOARD_SIZE && !madeMove; ++r) {
                        for (int c = 0; c < BOARD_SIZE && !madeMove; ++c) {
                            PieceBase* aiPiece = board.GetPiece(r, c);
                            if (aiPiece && aiPiece->IsAI()) {
                                int dr[4] = {1, 1, -1, -1};
                                int dc[4] = {-1, 1, -1, 1};
                                for (int d = 0; d < 4; ++d) {
                                    if (!aiPiece->IsKing() && dr[d] < 0) continue;
                                    int mr = r + dr[d];
                                    int mc = c + dc[d];
                                    int tr = r + 2 * dr[d];
                                    int tc = c + 2 * dc[d];
                                    if (tr >= 0 && tr < BOARD_SIZE && tc >= 0 && tc < BOARD_SIZE) {
                                        PieceBase* middle = board.GetPiece(mr, mc);
                                        if (board.GetPiece(tr, tc) == nullptr && middle && !middle->IsAI()) {
                                            board.RemovePiece(mr, mc);
                                            board.MovePiece(r, c, tr, tc);
                                            aiCaptureRow = tr;
                                            aiCaptureCol = tc;
                                            aiMultiCapture = true;
                                            madeMove = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // If no capture possible, try normal move
                    if (!madeMove && !aiMultiCapture) {
                        for (int r = 0; r < BOARD_SIZE && !madeMove; ++r) {
                            for (int c = 0; c < BOARD_SIZE && !madeMove; ++c) {
                                PieceBase* aiPiece = board.GetPiece(r, c);
                                if (aiPiece && aiPiece->IsAI()) {
                                    int dr[4] = {1, 1, -1, -1};
                                    int dc[4] = {-1, 1, -1, 1};
                                    for (int d = 0; d < 4; ++d) {
                                        if (!aiPiece->IsKing() && dr[d] < 0) continue;
                                        int nr = r + dr[d];
                                        int nc = c + dc[d];
                                        if (nr >= 0 && nr < BOARD_SIZE && nc >= 0 && nc < BOARD_SIZE &&
                                            board.GetPiece(nr, nc) == nullptr) {
                                            board.MovePiece(r, c, nr, nc);
                                            madeMove = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        currentTurn = HUMAN;  // Hand turn to player
                    }

                    // If AI can continue multi-capture
                    if (aiMultiCapture && board.CanCapture(board.GetPiece(aiCaptureRow, aiCaptureCol))) {
                        // Wait for next frame to continue capture
                    } else if (aiMultiCapture) {
                        aiMultiCapture = false;
                        currentTurn = HUMAN;
                    }

                    aiWaitTimer = 0;  // Reset timer for next AI action
                }
            }

            // ------------------ CHECK GAME END ------------------
            if (!board.HasMoves(true)) {
                winner = HUMAN;
                gameOver = true;
            } else if (!board.HasMoves(false)) {
                winner = AI;
                gameOver = true;
            }

            EndDrawing();  // End frame rendering
        }
    }

    CloseWindow();  // Clean up and close game window
    return 0;
}
