#include "raylib.h"
#include "othello.h"
#include "checkers.h"
#include "battleship.h"

enum game_type { NONE, OTHELLO, CHECKERS, BATTLESHIP, EXIT };

game_type ShowMainMenu() {
    InitWindow(600, 400, "Tactic Table");
    SetTargetFPS(60);
    game_type selection = NONE;

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(GOLD);
        DrawText("Tactic Table", 180, 30, 35, BLACK);
        DrawText("Select a Game", 200, 80, 25, DARKGRAY);

        Rectangle othelloBtn = {200, 120, 200, 50};
        Rectangle checkersBtn = {200, 180, 200, 50};
        Rectangle battleshipBtn = {200, 240, 200, 50};
        Rectangle exit = {200, 300, 200, 50};

        // Highlight if hovered
        if (CheckCollisionPointRec(GetMousePosition(), othelloBtn)) {
            DrawRectangleRec(othelloBtn, LIGHTGRAY);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                selection = OTHELLO;
                break;
            }
        }
        DrawText("Play Othello", 220, 135, 20, BROWN);

        if (CheckCollisionPointRec(GetMousePosition(), checkersBtn)) {
            DrawRectangleRec(checkersBtn, LIGHTGRAY);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                selection = CHECKERS;
                break;
            }
        }
        DrawText("Play Checkers", 220, 195, 20, BROWN);

        if (CheckCollisionPointRec(GetMousePosition(), battleshipBtn)) {
            DrawRectangleRec(battleshipBtn, LIGHTGRAY);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                selection = BATTLESHIP;
                break;
            }
        }

        DrawText("Play Battleship", 220, 255, 20, BROWN);
        

        if (CheckCollisionPointRec(GetMousePosition(), exit)) {
            DrawRectangleRec(exit, LIGHTGRAY);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                selection = EXIT;
                break;
            }
        }

        DrawText("Exit", 270, 320, 20, DARKBROWN);
        EndDrawing();
    }

    CloseWindow(); // Close menu before launching game
    return selection;
}

int main() {
    game_type game = ShowMainMenu();

    if (game == OTHELLO) 
    {
        RunOthello();
    } 
    else if (game == CHECKERS) 
    {
        RunCheckers();
    }
    else if(game == BATTLESHIP)
    {
        RunBattleship();
    }
    return 0;
}
