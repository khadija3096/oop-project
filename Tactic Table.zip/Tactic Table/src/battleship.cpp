#include "raylib.h"
#include <cstdlib>  
#include <ctime>    

// Constants defining window and grid dimensions
const int SCREEN_WIDTH = 800;    // Width of the game window
const int SCREEN_HEIGHT = 600;   // Height of the game window
const int GRID_SIZE = 10;        // 10x10 grid
const int CELL_SIZE = 30;        // Size of each cell in the grid
const int OFFSET_X_PLAYER = 50;  // X-offset for player's grid
const int OFFSET_X_ENEMY = 450;  // X-offset for enemy's grid
const int OFFSET_Y = 100;        // Y-offset for both grids

// Ship sizes (lengths) and count
const int SHIP_SIZES[] = {5, 4, 3, 3, 2}; // Array of ship sizes
const int SHIP_COUNT = sizeof(SHIP_SIZES) / sizeof(SHIP_SIZES[0]); // Total number of ships

// Cell status enumeration
enum CellStatus { EMPTY, SHIP, MISS, HIT }; // Represents the state of a cell
// Screen state enumeration
enum ScreenState { MENU, INSTRUCTIONS, GAME }; // Represents the current screen

// Base class representing a generic ship
class Ship {
public:
    int size, x, y;            // Size and position of the ship
    bool horizontal;           // Orientation of the ship
    bool placed, sunk;         // Flags for placement and if the ship is sunk

    Ship(int s) : size(s), x(0), y(0), horizontal(true), placed(false), sunk(false) {} // Constructor

    virtual const char* Type() const { return "Generic Ship"; } // Virtual method for polymorphism
    virtual ~Ship() {} // Virtual destructor for safe inheritance
};

// Derived class for a specific type of ship: Battleship
class Battleship : public Ship {
public:
    Battleship() : Ship(5) {} // Set size for battleship
    const char* Type() const override { return "Battleship"; } // Override type method
};

// Derived class for another specific type of ship: Submarine
class Submarine : public Ship {
public:
    Submarine() : Ship(3) {} // Set size for submarine
    const char* Type() const override { return "Submarine"; } // Override type method
};

// Class representing the game board
class Board {
public:
    int grid[GRID_SIZE][GRID_SIZE]; // 2D grid for cell states
    Ship* ships[SHIP_COUNT];        // Array of ship pointers

    Board() {
        Clear(); // Clear the grid
        for (int i = 0; i < SHIP_COUNT; i++) {
            // Alternate between different ship types using polymorphism
            if (i % 2 == 0)
                ships[i] = new Battleship();
            else
                ships[i] = new Submarine();
        }
    }

    ~Board() {
        for (int i = 0; i < SHIP_COUNT; i++) delete ships[i]; // Free allocated memory
    }

    void Clear() {
        for (int i = 0; i < GRID_SIZE; i++)
            for (int j = 0; j < GRID_SIZE; j++)
                grid[i][j] = EMPTY; // Set all cells to EMPTY
    }

    bool CanPlace(Ship* ship, int x, int y, bool horizontal) {
        for (int i = 0; i < ship->size; i++) {
            int px = x + (horizontal ? i : 0);
            int py = y + (horizontal ? 0 : i);
            if (px >= GRID_SIZE || py >= GRID_SIZE || grid[px][py] != EMPTY)
                return false; // Cannot place ship if out of bounds or overlapping
        }
        return true;
    }

    void PlaceShip(Ship* ship, int x, int y, bool horizontal) {
        ship->x = x;
        ship->y = y;
        ship->horizontal = horizontal;
        ship->placed = true;
        for (int i = 0; i < ship->size; i++) {
            int px = x + (horizontal ? i : 0);
            int py = y + (horizontal ? 0 : i);
            grid[px][py] = SHIP; // Place ship on grid
        }
    }

    void PlaceShipsRandomly() {
        for (int i = 0; i < SHIP_COUNT; i++) {
            Ship* ship = ships[i];
            bool placed = false;
            while (!placed) {
                int x = rand() % GRID_SIZE;
                int y = rand() % GRID_SIZE;
                bool hor = rand() % 2 == 0;
                if (CanPlace(ship, x, y, hor)) {
                    PlaceShip(ship, x, y, hor);
                    placed = true; // Try random positions until ship is placed
                }
            }
        }
    }

    bool Attack(int x, int y) {
        if (grid[x][y] == EMPTY) {
            grid[x][y] = MISS;
            return false; // Missed shot
        }
        else if (grid[x][y] == SHIP) {
            grid[x][y] = HIT;
            UpdateShips();
            return true; // Hit a ship
        }
        return false; // Already hit
    }

    void UpdateShips() {
        for (int i = 0; i < SHIP_COUNT; i++) {
            if (ships[i]->sunk) continue; // Skip already sunk ships
            bool sunk = true;
            for (int j = 0; j < ships[i]->size; j++) {
                int px = ships[i]->x + (ships[i]->horizontal ? j : 0);
                int py = ships[i]->y + (ships[i]->horizontal ? 0 : j);
                if (grid[px][py] != HIT) {
                    sunk = false; // If any part isn't hit, not sunk
                    break;
                }
            }
            if (sunk) ships[i]->sunk = true; // Mark ship as sunk
        }
    }

    bool AllShipsSunk() {
        for (int i = 0; i < SHIP_COUNT; i++)
            if (!ships[i]->sunk)
                return false; // Return false if any ship is not sunk
        return true; // All ships sunk
    }
};

int RunBattleship() {
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Battleship");
    SetTargetFPS(60);

    srand(time(NULL)); // Seed random number generator

    ScreenState currentScreen = MENU;

    Board playerBoard;
    Board enemyBoard;
    enemyBoard.PlaceShipsRandomly(); // Auto-place enemy ships
    playerBoard.PlaceShipsRandomly(); // (Optional) auto-place player ships

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        if (currentScreen == MENU) {
            DrawText("BATTLESHIP", 300, 100, 30, DARKBLUE);
            DrawText("Press ENTER to Play", 280, 200, 20, DARKGRAY);
            DrawText("Press I for Instructions", 270, 240, 20, DARKGRAY);

            if (IsKeyPressed(KEY_ENTER)) currentScreen = GAME;
            if (IsKeyPressed(KEY_I)) currentScreen = INSTRUCTIONS;

        } else if (currentScreen == INSTRUCTIONS) {
            DrawText("Instructions:", 50, 50, 20, BLACK);
            DrawText("1. Click on the enemy grid to attack.", 50, 80, 18, DARKGRAY);
            DrawText("2. Sink all enemy ships to win.", 50, 110, 18, DARKGRAY);
            DrawText("Press BACKSPACE to return.", 50, 160, 18, DARKGRAY);

            if (IsKeyPressed(KEY_BACKSPACE)) currentScreen = MENU;

        } else if (currentScreen == GAME) {
            // Draw Grids
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    // Player grid
                    DrawRectangleLines(OFFSET_X_PLAYER + i * CELL_SIZE, OFFSET_Y + j * CELL_SIZE, CELL_SIZE, CELL_SIZE, GRAY);
                    if (playerBoard.grid[i][j] == SHIP) DrawRectangle(OFFSET_X_PLAYER + i * CELL_SIZE, OFFSET_Y + j * CELL_SIZE, CELL_SIZE, CELL_SIZE, LIGHTGRAY);
                    else if (playerBoard.grid[i][j] == HIT) DrawCircle(OFFSET_X_PLAYER + i * CELL_SIZE + 15, OFFSET_Y + j * CELL_SIZE + 15, 10, RED);
                    else if (playerBoard.grid[i][j] == MISS) DrawCircle(OFFSET_X_PLAYER + i * CELL_SIZE + 15, OFFSET_Y + j * CELL_SIZE + 15, 5, DARKGRAY);

                    // Enemy grid
                    DrawRectangleLines(OFFSET_X_ENEMY + i * CELL_SIZE, OFFSET_Y + j * CELL_SIZE, CELL_SIZE, CELL_SIZE, GRAY);
                    if (enemyBoard.grid[i][j] == HIT) DrawCircle(OFFSET_X_ENEMY + i * CELL_SIZE + 15, OFFSET_Y + j * CELL_SIZE + 15, 10, RED);
                    else if (enemyBoard.grid[i][j] == MISS) DrawCircle(OFFSET_X_ENEMY + i * CELL_SIZE + 15, OFFSET_Y + j * CELL_SIZE + 15, 5, DARKGRAY);
                }
            }

            // Handle Mouse Click for Enemy Attack
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                Vector2 mouse = GetMousePosition();
                int i = (mouse.x - OFFSET_X_ENEMY) / CELL_SIZE;
                int j = (mouse.y - OFFSET_Y) / CELL_SIZE;
                if (i >= 0 && i < GRID_SIZE && j >= 0 && j < GRID_SIZE) {
                    enemyBoard.Attack(i, j);
                }
            }

            // Check win
            if (enemyBoard.AllShipsSunk()) {
                DrawText("YOU WIN!", 320, 50, 40, GREEN);
            }
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
