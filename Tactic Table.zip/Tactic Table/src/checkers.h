// checkers.h
#pragma once
void RunCheckers();
